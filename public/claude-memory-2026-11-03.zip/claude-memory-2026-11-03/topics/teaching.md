---
name: "teaching"
description: "Teaching style, course design, and instructional approach"
---

- Teaching style emphasizes concept-before-code sequencing, incremental disclosure, and plain-English property explanations
- Delivered a live-coded CSS classroom project — a YouTube Homepage Clone — for beginner students who had just finished HTML
- That session used a strict nine-step build order with Flexbox, Grid, responsive design, and Font Awesome; explicitly excluded JavaScript and frameworks
- Requested a full bootcamp-style CSS course (24 lessons, 4 modules)
- Interest in producing structured educational content on networking and computer science topics
- Creates beginner-level courses in CSS, React, and frontend development
- Built a 19-lesson React course (plain JavaScript, Vite-based) for beginner students, structured into four stages, culminating in a Student Course Management Dashboard capstone
- Requested a full Node.js + Express.js backend fundamentals course (26 lessons across 11 modules, strict no-future-concepts rule, in-memory data only, no auth/DB/deployment) for students who already know JS/React but are new to backend, culminating in a Student Management REST API capstone
- Requested a full PostgreSQL Database Development course (22-lesson roadmap across 14 modules, strict no-future-concepts rule, School Management Database as running example, no Node.js/Express/Prisma/auth) for students who know frontend/JS/React but have never learned databases or SQL, culminating in a School Management Database final project; later added Lesson 13 "Managing Database Structure" (ALTER TABLE/DROP TABLE) after the CRUD module, shifting later lessons
