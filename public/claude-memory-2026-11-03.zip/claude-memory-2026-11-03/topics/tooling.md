---
name: "tooling"
description: "Tools, workflows, and output-format habits in the user's work"
---

- Uses a `/humanizer` command/skill to rewrite or generate academic assignment content in a natural student voice, avoiding AI-sounding patterns
- Prefers deliverables output as Markdown files for download
- Background interest in document generation tooling — Node.js `docx` library for formatted Word documents
