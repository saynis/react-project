---
name: "recent-work"
description: "Recent work activity that doesn't rise to a standalone project"
---

- Completed a Java OOP individual assignment on Exception Handling, delivered as a formatted PDF with a cover page for submission
- Prepared for exams across multiple IT subjects, generating structured Q&A study guides from course slides — Systems Analysis and Design (SDLC, DFDs, ERDs), SQL/Advanced Database Systems (relational algebra, query optimization), Java OOP (encapsulation, inheritance, polymorphism, abstraction), Computer Hardware, and PHP/Internet Programming II
- Worked on ML coursework: a regression theory assignment (Part A) and a data foundations assignment (Assignment 02) using a survey dataset for binary classification; both processed through the `/humanizer` skill and delivered as `.md` files
- Reviewed and debugged a Somali restaurant website (HTML/CSS/JS) — found a missing script reference, CSS class naming inconsistencies between desktop and mobile styles, and an unimplemented hamburger menu toggle
- Produced a formatted Word document on Communications Network Architecture for a group assignment
