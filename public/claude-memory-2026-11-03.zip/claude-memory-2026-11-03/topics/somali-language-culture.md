---
name: "somali-language-culture"
description: "Interest in Somali language and culture across contexts"
---

- Long-standing interest in Somali language and culture, appearing across multiple contexts
- Has sought Python learning resources in Somali
- Strong connection to Somali culture and the broader Horn of Africa region, spanning Somali traditions, the Somali Region of Ethiopia, and Somali-language learning resources
- Engages with geospatial data and regional development projects
