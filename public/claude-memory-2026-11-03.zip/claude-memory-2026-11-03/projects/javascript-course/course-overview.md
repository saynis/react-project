---
name: "course-overview"
description: "Mahamed's three-level JavaScript course (Fundamentals, Intermediate, Advanced) — goals, teaching philosophy, and current lesson production status"
---

- Mahamed is a JavaScript instructor and curriculum designer
- Building a three-level JavaScript course: Fundamentals → Intermediate → Advanced
- Target audience is complete beginners who already know basic HTML and CSS
- Ultimate goal of the course is to prepare students for React.js
- Uses Claude as a senior curriculum consultant and content generator throughout the course-building process

## Teaching philosophy

- Practical over theoretical
- Beginner-friendly explanations
- Concepts should build naturally from prior lessons
- Never overwhelm students with advanced theory before they're ready

## Current state — lesson production

- Fundamentals level: all 15 lessons fully completed (variables through array methods, plus two mini projects: Quiz App and Todo App)
- Intermediate level: all lessons completed — DOM Basics, Events, Forms Validation, Debugging & DevTools, and a Mini Project (Personal Expense Tracker combining all Intermediate skills)
- Advanced level: six lessons completed — Local Storage with JSON, ES6 Features (combined into one lesson), Asynchronous JavaScript (concept), Promises, Async/Await, and Fetch API (using JSONPlaceholder as the practice API)
- Remaining Advanced lessons from the original twelve-topic roadmap are still to be produced

## On the horizon

- Completing the remaining Advanced level lessons through to the Final Project
- Approved Advanced roadmap sequencing: Local Storage → ES6 Features → Async concepts → Promises → Async/Await → Fetch API → [remaining topics] → Final Project
