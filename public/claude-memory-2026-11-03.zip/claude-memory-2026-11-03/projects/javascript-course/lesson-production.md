---
name: "lesson-production"
description: "How lessons are built for Mahamed's JavaScript course — file structure, humanizer writing rules, curriculum decisions on ES6 and async, and JSONPlaceholder"
---

## Standard lesson format

- Three files per lesson: `lesson.md` (plain-language explanations with real-world analogies), `examples.js` (runnable commented code), `assignment.md` (three tasks + bonus challenge)
- DOM and project lessons also include `index.html` with interactive demos
- The Personal Expense Tracker project established the standard three-file structure (index.html, style.css, script.js) for all project-based lessons

## Humanizer rules (applied to all lessons)

- No em dashes in prose — only in headings matching course naming convention
- No AI vocabulary (delve, crucial, vibrant, seamless, robust, etc.)
- No forced rule-of-three constructions
- No "let me help you" framing
- Varied sentence rhythm

## Curriculum decisions and learnings

- ES6 Features was identified as the critical bridge lesson — most React-relevant in the entire roadmap, foundational for all async topics
- ES6 topics to include: template literals, destructuring, spread/rest, default parameters, object shorthand, arrow function review, optional chaining, nullish coalescing
- ES6 topics to defer: deep `this` binding, ES Modules, generators, iterators, Symbols, Map/Set, Proxy, Reflect
- Promises and Async/Await should remain as two separate lessons (previously combined, then split back on Mahamed's request)

## Ways of working

- Mahamed works through curriculum sequencing decisions collaboratively before lesson production begins
- Communication with Claude has been conducted in Somali with English retained for all technical terms

## Tools & resources

- JSONPlaceholder: free practice API used for the Fetch lesson (no authentication required)
