---
name: "profile"
description: "Who the user is — role, teaching focus, production work"
---

- Full name: Mahamed Abdifatah Mahamed
- Coding instructor and curriculum designer
- Teaches beginner frontend (CSS, HTML) and data science/ML topics
- Does both classroom instruction and academic ML coursework
- Student at Management and Public Service College, Department of Information Technology
