---
name: "preferences"
description: "How the user wants Claude to respond"
---

- Deliver output as Markdown files for download
- Prefers minimal back-and-forth
- Prefers a directive communication style
- When generating academic assignment content, write in a natural student voice and avoid AI-sounding patterns
