---
name: "drizzle-orm-course"
description: "Short beginner course \"Drizzle ORM with PostgreSQL\" (8-10 lessons, TypeScript/Node.js), a follow-up to the user's PostgreSQL course"
---

- Building a short beginner course "Drizzle ORM with PostgreSQL" as a continuation of their finished PostgreSQL course
- Students already know SQL, CRUD, relationships, foreign keys, JOINs, aggregates; course must not reteach PostgreSQL
- Each lesson follows their PostgreSQL course structure (objectives, why, concept, analogy, visual, syntax, example, SQL vs Drizzle, mistakes, mini practice, assignment, requirements, restrictions, expected result, concepts used)
- Plan: ~10 lessons, final project is a Student Management database layer (students + sections); no Express, auth, Docker, or deployment
- Wants current official Drizzle docs verified before writing install commands; output as one Markdown file
