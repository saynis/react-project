---
name: "prisma-orm-course"
description: "Beginner \"Prisma ORM\" course (10 lessons, TypeScript, PostgreSQL) bridging the user's PostgreSQL course to Node.js + Express + REST API"
---

- Building a short beginner Prisma ORM course, ~8-10 lessons, for students who already finished the user's PostgreSQL course (psql, SQL, joins, relationships, aggregates)
- Lesson order: What is Prisma, Setup, Schema & Models, Migrations, Prisma Client, Create & Read, Update & Delete, Relationships & Foreign Keys, Relations/Include/Filtering, Mini CRUD Project
- Every lesson uses a fixed section template (objectives, why, concept, analogy, visual, SQL vs Prisma, syntax, example, explanation, common mistakes, mini practice, assignment, requirements, restrictions, expected result, concepts used)
- Teach Prisma alongside the SQL it maps to; never hide SQL; assignments may only use concepts taught so far
- Use current stable Prisma conventions (verify official docs first), TypeScript only as needed, PostgreSQL throughout, one consistent example database
- Next course after this: Node.js + Express + REST API
