---
name: "somali-region-geospatial"
description: "Extracting administrative boundaries for the Somali Region of Ethiopia from GeoJSON sources"
---

- Geospatial data task extracting Ethiopia Somali Region administrative boundaries at region, zone, and woreda levels
- Source data is GitHub-hosted GeoJSON
- Deliverables: filtered GeoJSON files and a summary coordinate table
- Sandbox network constraints surfaced during this work — blocked: HDX, GitHub LFS media hosts; allowlisted: `codeload.github.com`, `raw.githubusercontent.com`
