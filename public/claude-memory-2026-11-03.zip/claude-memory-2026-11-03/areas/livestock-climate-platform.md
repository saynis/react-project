---
name: "livestock-climate-platform"
description: "Presentation project — Livestock & Climate Intelligence Platform pitch deck for Somali Region government/NGO audience"
---

- Building a 6-slide government/NGO presentation titled "Livestock & Climate Intelligence Platform"
- Audience: government officials, humanitarian orgs, NGOs, development partners in [[somali-region-geospatial]] context
- Purpose: pitch a platform that turns climate + livestock data into early warning and drought resilience
- Visual identity: hand-drawn watercolor illustration style, cream paper background, elegant sketch lines, Somali Region Ethiopia pastoral landscape, human-centered storytelling, minimal text, 16:9, no futuristic tech imagery or realistic photos
- Tone: policy briefing, not software advertisement; avoid technical jargon
- Slide sequence: 1) platform intro, 2) problem (drought outpaces decisions), 3) fragmented data → unified intelligence, 4) data-to-action process flow, 5) differentiation (decision support), 6) partnership/impact closing
